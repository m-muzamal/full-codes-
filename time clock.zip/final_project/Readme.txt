Hi!

--> Name: Muhammad Muzammal
--> Registration: 2020-ag-5773
--> Degree: BS(CS)
--> Semester: 3rd
--> Section: B 

	. It is a .cpp program that display clock.
	. For execution press F10 or execution button and wait a moment for the response then give the input.

Note: If you are on VS Code then to stop the execution process delet the terminal rether then to close the terminal.